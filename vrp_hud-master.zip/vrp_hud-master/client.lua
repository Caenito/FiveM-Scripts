--  ██╗ ██╗ ██████╗ ██╗ ██████╗██╗  ██╗     █████╗ ███████╗███████╗    ███╗   ██╗██╗ ██████╗  ██████╗  █████╗ 
-- ████████╗██╔══██╗██║██╔════╝██║  ██║    ██╔══██╗██╔════╝██╔════╝    ████╗  ██║██║██╔════╝ ██╔════╝ ██╔══██╗
-- ╚██╔═██╔╝██████╔╝██║██║     ███████║    ███████║███████╗███████╗    ██╔██╗ ██║██║██║  ███╗██║  ███╗███████║
-- ████████╗██╔══██╗██║██║     ██╔══██║    ██╔══██║╚════██║╚════██║    ██║╚██╗██║██║██║   ██║██║   ██║██╔══██║
-- ╚██╔═██╔╝██║  ██║██║╚██████╗██║  ██║    ██║  ██║███████║███████║    ██║ ╚████║██║╚██████╔╝╚██████╔╝██║  ██║
--  ╚═╝ ╚═╝ ╚═╝  ╚═╝╚═╝ ╚═════╝╚═╝  ╚═╝    ╚═╝  ╚═╝╚══════╝╚══════╝    ╚═╝  ╚═══╝╚═╝ ╚═════╝  ╚═════╝ ╚═╝  ╚═╝

-- Project by machiamavlad --
------ www.youtube.com/machiamavlad ------
-- some functions is from "vRP_market" by Mihnea Banditul --

local showHud = true
local recoilHud = false

function isCursorInPosition(x,y,width,height)
    local sx, sy = GetActiveScreenResolution()
  local cx, cy = GetNuiCursorPosition ( )
  local cx, cy = (cx / sx), (cy / sy)
  
    local width = width / 2
    local height = height / 2
  
  if (cx >= (x - width) and cx <= (x + width)) and (cy >= (y - height) and cy <= (y + height)) then
      return true
  else
      return false
  end
end

function showToolTip(text, font, size)
    local sx, sy = GetActiveScreenResolution()
    local cx, cy = GetNuiCursorPosition()
    local cx, cy = ( cx / sx ) + 0.008, ( cy / sy ) + 0.027

    SetTextScale(size, size)
    SetTextFont(font)
    SetTextProportional(1)
    SetTextColour(255, 255, 255, 255)
    SetTextDropshadow(0, 0, 0, 0, 255)
    SetTextEdge(0, 0, 0, 0, 255)
    SetTextEntry("STRING")
    SetTextCentre(1)
    SetTextOutline()
    AddTextComponentString(text)
    DrawText(cx, cy + 0.007)
end

function drawScreenText(x,y ,width,height,scale, text, r,g,b,a, outline, font, center)
    SetTextFont(font)
    SetTextProportional(0)
    SetTextScale(scale, scale)
    SetTextColour(r, g, b, a)
    SetTextDropShadow(0, 0, 0, 0,255)
    SetTextEdge(1, 0, 0, 0, 255)
    SetTextDropShadow()
    SetTextCentre(center)
    if(outline)then
        SetTextOutline()
    end
    SetTextEntry("STRING")
    AddTextComponentString(text)
    DrawText(x - width/2, y - height/2 + 0.005)
end

function drawWatermark(x,y ,width,height,scale, text, r,g,b,a, outline, font, center)
    SetTextFont(7)
    SetTextProportional(0)
    SetTextScale(scale, scale)
    SetTextColour(r, g, b, a)
    SetTextDropShadow(0, 0, 0, 0,255)
    SetTextEdge(1, 0, 0, 0, 255)
    SetTextDropShadow()
    SetTextCentre(center)
    if(outline)then
        SetTextOutline()
    end
    SetTextEntry("STRING")
    AddTextComponentString(text)
    DrawText(x - width/2, y - height/2 + 0.005)
end

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(0)

		drawWatermark(0.90, 0.962, 0,0, 0.5, "~b~Server~w~ Roleplay", 255, 255, 255, 230, 1, 0, 1)
	end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)

        drawScreenText(0.5, 0.978, 0,0, 0.25, "Press [comma] for the cursor", 255, 255, 255, 230, 1, 0, 1)
        drawScreenText(0.92, 0.94, 0,0, 0.3, "YourServer - ~b~v1.0", 255, 255, 255, 230, 1, 0, 1)
        --drawScreenText(0.94, 0.962, 0,0, 0.3, "Scripter: ~b~machiamavlad", 255, 255, 255, 230, 1, 0, 1)
    end
end)

discordText = "Discord Server"
ipText = "IP Server"

isCursor = false

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        local discordAlpha = 180
        local ipAlpha = 180
        
        if(showHud)then
            showHudAlpha = 255
        else
            showHudAlpha = 145
        end
        if(recoilHud)then
            recoilAlpha = 255
        else
            recoilAlpha = 180
        end
        
        local hp = math.floor(GetEntityHealth(GetPlayerPed(-1)) / 2)
        
        if(isCursor)then        
            ShowCursorThisFrame()
            
            DisableControlAction(0,24,true)
            DisableControlAction(0,47,true)
            DisableControlAction(0,58,true)
            DisableControlAction(0,263,true)
            DisableControlAction(0,264,true)
            DisableControlAction(0,257,true)
            DisableControlAction(0,140,true)
            DisableControlAction(0,141,true)
            DisableControlAction(0,142,true)
            DisableControlAction(0,143,true)
            DisableControlAction(0, 1, true)
            DisableControlAction(0, 2, true)
            
            if(showHud)then
                if isCursorInPosition(0.82, 0.02, 0.02, 0.035) then
                    SetCursorSprite(5)
                    showHudAlpha = 255
                    if(showHud)then
                        showToolTip("Hide HUD", 4, 0.4)
                    else
                        showToolTip("Show HUD", 4, 0.4)
                    end
                    if(IsDisabledControlJustPressed(0, 24))then
                        showHud = not showHud
                    end
                elseif isCursorInPosition(0.85, 0.02, 0.016, 0.03) then
                    SetCursorSprite(5)
                        local theHealth = (GetEntityHealth(GetPlayerPed(-1)) - 100)
                        showToolTip("Health: ~r~"..theHealth.."%", 4, 0.4)
                elseif isCursorInPosition(0.80, 0.02, 0.02, 0.035) then
                    SetCursorSprite(5)
                    recoilAlpha = 255
                    if(recoilHud)then
                        showToolTip("Recoil OFF", 4, 0.4)
                    else
                        showToolTip("Recoil ON", 4, 0.4)

                    end
                    if(IsDisabledControlJustPressed(0, 24))then
                        recoilHud = not recoilHud
                        TriggerEvent("on-off-Recoil")
                    end
                elseif isCursorInPosition(0.76, 0.020, 0.017, 0.035) then
                    SetCursorSprite(5)
                    showToolTip(discordText, 4, 0.4)
                    discordAlpha = 255
                    if(IsDisabledControlJustPressed(0, 24))then
                        discordText = "Copied to clipboard"
                        SetClipboard("discord.pulamea/ro")
                        SetTimeout(1500, function()
                            local discordText = "Our discord server"
                        end)
                    end
                elseif isCursorInPosition(0.78, 0.020, 0.017, 0.035) then
                    SetCursorSprite(5)
                    showToolTip(ipText, 4, 0.4)
                    ipAlpha = 255
                    if(IsDisabledControlJustPressed(0, 24))then
                        ipText = "IP Server copied"
                        SetClipboard("127.0.0.1")
                        SetTimeout(1500, function()
                            local ipText = "IP Server"
                        end)
                    end
                else
                    SetCursorSprite(1)
                end
            else
                if isCursorInPosition(0.82, 0.02, 0.02, 0.035) then
                    SetCursorSprite(5)
                    if(showHud)then
                        showToolTip({"Hide HUD", 4, 0.4})
                    else
                        showToolTip({"Show HUD", 4, 0.4})
                    end
                    if(IsDisabledControlJustPressed(0, 24))then
                        showHud = not showHud
                    end
                else
                    SetCursorSprite(1)
                end
            end
        end
        if(showHud)then
            DrawSprite("heart", "heart", 0.85, 0.02, 0.016, 0.030, 0.0, 255, 255, 255, math.floor(tonumber(255/100*hp)))
            DrawSprite("recoil", "recoil",0.80, 0.02, 0.02, 0.040, 0.1, 255, 255, 255, recoilAlpha)
            DrawSprite("hideHudG", "hideHudG",0.82, 0.02, 0.02, 0.040, 0.1, 255, 255, 255, showHudAlpha)
            DrawSprite("discordIcon", "discordIcon", 0.76, 0.020, 0.017, 0.040, 0.0, 255, 255, 255, discordAlpha)
            DrawSprite("ipIcon", "ipIcon", 0.78, 0.020, 0.017, 0.040, 0.1, 255, 255, 255, ipAlpha)
        else
            DrawSprite("hideHud", "hideHud",0.82, 0.02, 0.02, 0.040, 0.1, 255, 255, 255, showHudAlpha)
        end
        
        if(IsControlJustPressed(1, 82))then
            isCursor = not isCursor
        end
    end
end)


function SetClipboard(text) 
    SendNUIMessage({
        text = text
    })
end


